<?php
 require_once '../web_db/connection.php'; 
class multi_values{


 function update_university( $name, $type, $account){
$con = new dbconnection();
$con->con_users();

$query="update university  set name= '$name', type= '$type', account= '$account'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_student( $name, $last_name, $gender, $university, $department){
$con = new dbconnection();
$con->con_users();

$query="update student  set name= '$name', last_name= '$last_name', gender= '$gender', university= '$university', department= '$department'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_job( $name, $student, $school_name, $description){
$con = new dbconnection();
$con->con_users();

$query="update job  set name= '$name', student= '$student', school_name= '$school_name', description= '$description'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_subject( $name, $university){
$con = new dbconnection();
$con->con_users();

$query="update subject  set name= '$name', university= '$university'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_class( $nummber, $total){
$con = new dbconnection();
$con->con_users();

$query="update class  set nummber= '$nummber', total= '$total'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_year( $name, $department){
$con = new dbconnection();
$con->con_users();

$query="update year  set name= '$name', department= '$department'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_account( $username, $password, $account_category){
$con = new dbconnection();
$con->con_users();

$query="update account  set username= '$username', password= '$password', account_category= '$account_category'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_account_category( $name){
$con = new dbconnection();
$con->con_users();

$query="update account_category  set name= '$name'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_test( $subject, $maximum_marks, $date, $student, $university, $department){
$con = new dbconnection();
$con->con_users();

$query="update test  set subject= '$subject', maximum_marks= '$maximum_marks', date= '$date', student= '$student', university= '$university', department= '$department'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_department( $name, $university){
$con = new dbconnection();
$con->con_users();

$query="update department  set name= '$name', university= '$university'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_company( $name, $account, $address){
$con = new dbconnection();
$con->con_users();

$query="update company  set name= '$name', account= '$account', address= '$address'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}

}

