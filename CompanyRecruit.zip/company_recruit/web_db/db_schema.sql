
--
-- Table structure for table `university`
--

CREATE TABLE IF NOT EXISTS `university` (
`university_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`type`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`university_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
`student_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
, `university`     int(11)   
, `department`     int(11)   

,PRIMARY KEY (`student_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
`job_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`school_name`     VARCHAR(60) 
,`description`     VARCHAR(60) 
, `student`     int(11)   

,PRIMARY KEY (`job_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
`subject_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `university`     int(11)   

,PRIMARY KEY (`subject_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
`class_id`     int(11) NOT NULL AUTO_INCREMENT 
,`nummber`     VARCHAR(60) 
, `total`     int(11)   

,PRIMARY KEY (`class_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `year`
--

CREATE TABLE IF NOT EXISTS `year` (
`year_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `department`     int(11)   

,PRIMARY KEY (`year_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
, `account_category`     int(11)   

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
`test_id`     int(11) NOT NULL AUTO_INCREMENT 
, `maximum_marks`     int(11)   
,`date`     Date 
, `subject`     int(11)   
, `student`     int(11)   
, `university`     int(11)   
, `department`     int(11)   

,PRIMARY KEY (`test_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`department_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
, `university`     int(11)   

,PRIMARY KEY (`department_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
`company_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`address`     VARCHAR(60) 
, `account`     int(11)   

,PRIMARY KEY (`company_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

