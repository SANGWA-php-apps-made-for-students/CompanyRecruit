<?php
 require_once '../web_db/connection.php'; 
class multi_values{


  function list_university() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from university";
?>
<table class="new_data_table">
 <thead><tr>
 <td> university </td>
 <td> name </td>
 <td> type </td>
 <td> account </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['university_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['type']; ?>
</td>
<td>
<?php echo $row['account']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_student() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from student";
?>
<table class="new_data_table">
 <thead><tr>
 <td> student </td>
 <td> name </td>
 <td> last_name </td>
 <td> gender </td>
 <td> university </td>
 <td> department </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['student_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['last_name']; ?>
</td>
<td>
<?php echo $row['gender']; ?>
</td>
<td>
<?php echo $row['university']; ?>
</td>
<td>
<?php echo $row['department']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_job() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from job";
?>
<table class="new_data_table">
 <thead><tr>
 <td> job </td>
 <td> name </td>
 <td> student </td>
 <td> school_name </td>
 <td> description </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['job_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['student']; ?>
</td>
<td>
<?php echo $row['school_name']; ?>
</td>
<td>
<?php echo $row['description']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_subject() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from subject";
?>
<table class="new_data_table">
 <thead><tr>
 <td> subject </td>
 <td> name </td>
 <td> university </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['subject_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['university']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_class() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from class";
?>
<table class="new_data_table">
 <thead><tr>
 <td> class </td>
 <td> nummber </td>
 <td> total </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['class_id']; ?>
</td>
<td>
<?php echo $row['nummber']; ?>
</td>
<td>
<?php echo $row['total']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_year() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from year";
?>
<table class="new_data_table">
 <thead><tr>
 <td> year </td>
 <td> name </td>
 <td> department </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['year_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['department']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_account() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
?>
<table class="new_data_table">
 <thead><tr>
 <td> account </td>
 <td> username </td>
 <td> password </td>
 <td> account_category </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td>
<?php echo $row['username']; ?>
</td>
<td>
<?php echo $row['password']; ?>
</td>
<td>
<?php echo $row['account_category']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_account_category() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account_category";
?>
<table class="new_data_table">
 <thead><tr>
 <td> account_category </td>
 <td> name </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['account_category_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_test() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from test";
?>
<table class="new_data_table">
 <thead><tr>
 <td> test </td>
 <td> subject </td>
 <td> maximum_marks </td>
 <td> date </td>
 <td> student </td>
 <td> university </td>
 <td> department </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['test_id']; ?>
</td>
<td>
<?php echo $row['subject']; ?>
</td>
<td>
<?php echo $row['maximum_marks']; ?>
</td>
<td>
<?php echo $row['date']; ?>
</td>
<td>
<?php echo $row['student']; ?>
</td>
<td>
<?php echo $row['university']; ?>
</td>
<td>
<?php echo $row['department']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_department() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from department";
?>
<table class="new_data_table">
 <thead><tr>
 <td> department </td>
 <td> name </td>
 <td> university </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['department_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['university']; ?>
</td>

</tr>
<?php }?></table>
<?php }
  function list_company() {
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from company";
?>
<table class="new_data_table">
 <thead><tr>
 <td> company </td>
 <td> name </td>
 <td> account </td>
 <td> address </td>

</tr></thead>

 <?php  foreach ($db->query($sql) as $row) {?><tr> 

<td>
<?php echo $row['company_id']; ?>
</td>
<td>
<?php echo $row['name']; ?>
</td>
<td>
<?php echo $row['account']; ?>
</td>
<td>
<?php echo $row['address']; ?>
</td>

</tr>
<?php }?></table>
<?php }
 function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_id_by_account_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account.account_id from account where account.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        echo $userid;
    } function get_university_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select university.university_id,   university.name from university";
        ?>
        <select class="textbox cbo_university"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_university_id_by_university_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    university.university_id from university where university.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        echo $userid;
    } function get_department_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select department.department_id,   department.name from department";
        ?>
        <select class="textbox cbo_department"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['department_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_department_id_by_department_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    department.department_id from department where department.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['department_id'];
        echo $userid;
    } function get_student_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select student.student_id,   student.name from student";
        ?>
        <select class="textbox cbo_student"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['student_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_student_id_by_student_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    student.student_id from student where student.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['student_id'];
        echo $userid;
    } function get_university_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select university.university_id,   university.name from university";
        ?>
        <select class="textbox cbo_university"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_university_id_by_university_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    university.university_id from university where university.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        echo $userid;
    } function get_department_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select department.department_id,   department.name from department";
        ?>
        <select class="textbox cbo_department"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['department_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_department_id_by_department_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    department.department_id from department where department.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['department_id'];
        echo $userid;
    } function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_category_id_by_account_category_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account_category.account_category_id from account_category where account_category.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        echo $userid;
    } function get_subject_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select subject.subject_id,   subject.name from subject";
        ?>
        <select class="textbox cbo_subject"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['subject_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_subject_id_by_subject_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    subject.subject_id from subject where subject.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['subject_id'];
        echo $userid;
    } function get_student_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select student.student_id,   student.name from student";
        ?>
        <select class="textbox cbo_student"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['student_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_student_id_by_student_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    student.student_id from student where student.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['student_id'];
        echo $userid;
    } function get_university_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select university.university_id,   university.name from university";
        ?>
        <select class="textbox cbo_university"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_university_id_by_university_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    university.university_id from university where university.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        echo $userid;
    } function get_department_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select department.department_id,   department.name from department";
        ?>
        <select class="textbox cbo_department"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['department_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_department_id_by_department_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    department.department_id from department where department.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['department_id'];
        echo $userid;
    } function get_university_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select university.university_id,   university.name from university";
        ?>
        <select class="textbox cbo_university"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_university_id_by_university_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    university.university_id from university where university.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        echo $userid;
    } function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.account_id,   account.name from account";
        ?>
        <select class="textbox cbo_account"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

 function get_account_id_by_account_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    account.account_id from account where account.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        echo $userid;
    }

}

