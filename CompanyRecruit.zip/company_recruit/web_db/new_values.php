<?php

class new_values {

    function new_university($name, $type, $account) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into university values(:university_id, :name,  :type,  :account)");
        $stm->execute(array(':university_id' => 0, ':name' => $name, ':type' => $type, ':account' => $account
        ));
    }

    function new_student($name, $last_name, $gender, $university, $department) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into student values(:student_id, :name,  :last_name,  :gender,  :university,  :department)");
        $stm->execute(array(':student_id' => 0, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':university' => $university, ':department' => $department
        ));
    }

    function new_job($name, $student, $school_name, $description) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into job values(:job_id, :name,  :student,  :school_name,  :description)");
        $stm->execute(array(':job_id' => 0, ':name' => $name, ':student' => $student, ':school_name' => $school_name, ':description' => $description
        ));
    }

    function new_subject($name, $university) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into subject values(:subject_id, :name,  :university)");
        $stm->execute(array(':subject_id' => 0, ':name' => $name, ':university' => $university
        ));
    }

    function new_class($nummber, $total) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into class values(:class_id, :nummber,  :total)");
        $stm->execute(array(':class_id' => 0, ':nummber' => $nummber, ':total' => $total
        ));
    }

    function new_year($name, $department) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into year values(:year_id, :name,  :department)");
        $stm->execute(array(':year_id' => 0, ':name' => $name, ':department' => $department
        ));
    }

    function new_account($username, $password, $account_category) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category
        ));
    }

    function new_account_category($name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name
        ));
    }

    function new_test($subject, $maximum_marks, $date, $student, $university, $department) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into test values(:test_id, :subject,  :maximum_marks,  :date,  :student,  :university,  :department)");
        $stm->execute(array(':test_id' => 0, ':subject' => $subject, ':maximum_marks' => $maximum_marks, ':date' => $date, ':student' => $student, ':university' => $university, ':department' => $department
        ));
    }

    function new_department($name, $university) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into department values(:department_id, :name,  :university)");
        $stm->execute(array(':department_id' => 0, ':name' => $name, ':university' => $university
        ));
    }

    function new_company($name, $account, $address) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into company values(:company_id, :name,  :account,  :address)");
        $stm->execute(array(':company_id' => 0, ':name' => $name, ':account' => $account, ':address' => $address
        ));
    }

}
