$(document).ready(function () {
get_new_data_hide_show();

        get_account_id_combo();        get_university_id_combo();        get_department_id_combo();        get_student_id_combo();        get_university_id_combo();        get_department_id_combo();        get_account_category_id_combo();        get_subject_id_combo();        get_student_id_combo();        get_university_id_combo();        get_department_id_combo();        get_university_id_combo();        get_account_id_combo();
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_university_id_combo() {
    try {
        $('.cbo_university').change(function () {
            var cbo_university = $('.cbo_university option:selected').text();
            $.post('../Admin/handler.php', {cbo_university: cbo_university}, function (data) {
                $('#txt_university_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_department_id_combo() {
    try {
        $('.cbo_department').change(function () {
            var cbo_department = $('.cbo_department option:selected').text();
            $.post('../Admin/handler.php', {cbo_department: cbo_department}, function (data) {
                $('#txt_department_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_student_id_combo() {
    try {
        $('.cbo_student').change(function () {
            var cbo_student = $('.cbo_student option:selected').text();
            $.post('../Admin/handler.php', {cbo_student: cbo_student}, function (data) {
                $('#txt_student_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_university_id_combo() {
    try {
        $('.cbo_university').change(function () {
            var cbo_university = $('.cbo_university option:selected').text();
            $.post('../Admin/handler.php', {cbo_university: cbo_university}, function (data) {
                $('#txt_university_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_department_id_combo() {
    try {
        $('.cbo_department').change(function () {
            var cbo_department = $('.cbo_department option:selected').text();
            $.post('../Admin/handler.php', {cbo_department: cbo_department}, function (data) {
                $('#txt_department_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').text();
            $.post('../Admin/handler.php', {cbo_account_category: cbo_account_category}, function (data) {
                $('#txt_account_category_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_subject_id_combo() {
    try {
        $('.cbo_subject').change(function () {
            var cbo_subject = $('.cbo_subject option:selected').text();
            $.post('../Admin/handler.php', {cbo_subject: cbo_subject}, function (data) {
                $('#txt_subject_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_student_id_combo() {
    try {
        $('.cbo_student').change(function () {
            var cbo_student = $('.cbo_student option:selected').text();
            $.post('../Admin/handler.php', {cbo_student: cbo_student}, function (data) {
                $('#txt_student_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_university_id_combo() {
    try {
        $('.cbo_university').change(function () {
            var cbo_university = $('.cbo_university option:selected').text();
            $.post('../Admin/handler.php', {cbo_university: cbo_university}, function (data) {
                $('#txt_university_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_department_id_combo() {
    try {
        $('.cbo_department').change(function () {
            var cbo_department = $('.cbo_department option:selected').text();
            $.post('../Admin/handler.php', {cbo_department: cbo_department}, function (data) {
                $('#txt_department_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_university_id_combo() {
    try {
        $('.cbo_university').change(function () {
            var cbo_university = $('.cbo_university option:selected').text();
            $.post('../Admin/handler.php', {cbo_university: cbo_university}, function (data) {
                $('#txt_university_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}


});

function get_new_data_hide_show(){
     $('.new_data_hider').click(function (){
         $('.new_data_box').slideToggle();
     });
    
}
