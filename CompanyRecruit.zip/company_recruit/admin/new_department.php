<?php
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_department'])){

$name = $_POST['txt_name'];
$university = $_POST['txt_university_id'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_department($name, $university);
}
?>

 <html>
<head>
<title>
department</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_department.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_university_id"   name="txt_university_id"/>
      <?php
            include 'admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div><div class="parts eighty_centered off saved_dialog">
 department saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  department</div>
 <table class="new_data_table">


<tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
 <tr><td>university :</td><td> <?php get_university_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="button" name="send_department" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
<?php 
 $obj = new multi_values();
$obj->list_department(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>


function get_university_combo() {
    $obj = new multi_values();
    $obj->get_university_in_combo();
}
