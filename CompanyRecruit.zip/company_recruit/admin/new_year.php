<?php
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_year'])){

$name = $_POST['txt_name'];
$department = $_POST['txt_department_id'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_year($name, $department);
}
?>

 <html>
<head>
<title>
year</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_year.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_department_id"   name="txt_department_id"/>
      <?php
            include 'admin_header.php';
                ?>

<div class="parts eighty_centered no_paddin_shade_no_Border">    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div><div class="parts eighty_centered off saved_dialog">
 year saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered ">  year</div>
 <table class="new_data_table">


<tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
 <tr><td>department :</td><td> <?php get_department_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="button" name="send_year" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
<?php 
 $obj = new multi_values();
$obj->list_year(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>


function get_department_combo() {
    $obj = new multi_values();
    $obj->get_department_in_combo();
}
