if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}if (isset($_POST['cbo_university'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_university_id_by_university_name($_POST['cbo_university']);
    return $id;
}if (isset($_POST['cbo_department'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_department_id_by_department_name($_POST['cbo_department']);
    return $id;
}if (isset($_POST['cbo_student'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_student_id_by_student_name($_POST['cbo_student']);
    return $id;
}if (isset($_POST['cbo_university'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_university_id_by_university_name($_POST['cbo_university']);
    return $id;
}if (isset($_POST['cbo_department'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_department_id_by_department_name($_POST['cbo_department']);
    return $id;
}if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}if (isset($_POST['cbo_subject'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_subject_id_by_subject_name($_POST['cbo_subject']);
    return $id;
}if (isset($_POST['cbo_student'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_student_id_by_student_name($_POST['cbo_student']);
    return $id;
}if (isset($_POST['cbo_university'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_university_id_by_university_name($_POST['cbo_university']);
    return $id;
}if (isset($_POST['cbo_department'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_department_id_by_department_name($_POST['cbo_department']);
    return $id;
}if (isset($_POST['cbo_university'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_university_id_by_university_name($_POST['cbo_university']);
    return $id;
}if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name($_POST['cbo_account']);
    return $id;
}
