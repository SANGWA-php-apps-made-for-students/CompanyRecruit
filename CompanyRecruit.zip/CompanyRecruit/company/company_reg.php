<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="company_reg.php" method="post">
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="#">Home</a>             
                     
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                       <a href="../login.php">Login </a>
                        <a href="../register_page.php">REgister </a>

                    </div>

                </div>
                <div class="parts full_center_two_h heit_free margin_free">
                    <div class="parts fixed_box_5x" id="bg1">
                        <div class="parts  full_center_two_h heit_free margin_free skin">  ADDING YOUR COMPANY</div>
                        <table class="new_data_table">
                            <tr><td>Company name:</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
                            <tr><td>Address :</td><td><input type="text"     name="txt_address" required class="textbox" />                                                          </td></tr>
                            <tr><td>username :</td><td> <input type="email"     name="txt_username" required class="textbox" />  </td></tr>
                            <tr><td>password :</td><td> <input type="password"     name="txt_password" required class="textbox"  /> </td></tr>
                            <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_company" value="Save"/>  </td></tr>
                        </table>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder "style="background-color: #000066; color: #fff; text-align: center">
                    Copyrights  <?php echo date("Y"); ?>
                </div> 
            </div>
        </form>
    </body>
</html>
<?php
if (isset($_POST['send_company'])) {
    include '../web_db/multi_values.php';
    
    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_account($username, $password, '3');

    $obj_mul = new multi_values();
    $last_acc = $obj_mul->get_last_account();

    $name = $_POST['txt_name'];
    $address = $_POST['txt_address'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_company($name, $last_acc, $address);
}