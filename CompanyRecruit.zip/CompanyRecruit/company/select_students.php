<?php
session_start();
if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_job'])) {
    $name = $_POST['txt_name'];
    $student = $_POST['txt_student_id'];
    $school_name = $_POST['txt_school_name'];
    $description = $_POST['txt_description'];
    $account=$_SESSION['userid'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_job($name, $student, $school_name, $description,$account);
    ?>
        <script>
            alert('Job saved successfully');
        </script>
        <?php
    ?>
    <script>
        aler('Job saved successfully');
    </script>
    <?php
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            #dialog_child tr,#dialog_child tr a{
                color: #fff;
            }

        </style>
    </head>
    <body>
        <form action="select_students.php" method="post">
            <input type="hidden" id="txt_student_id" name="txt_student_id">
            <div class="parts abs_full accept_abs off" style="position: absolute; top: 0px; height: 100%; opacity: 0.5;"  id="dialog_students">
            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off no_shade_noBorder" style="opacity: 1; background-color: #153c4c;" id="dialog_child">
                <table class="new_data_table">
                    <tr><td>Title :</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
                    <tr><td>graduate :</td><td>  <input type="text"  id="student_name"   name="txt_name" required class="textbox" />                    </td></tr>
                    <tr><td>University name :</td><td> <input type="text" id="txt_school_name"    name="txt_school_name" required class="textbox" />  </td></tr>
                    <tr><td>Job description :</td><td> <input type="text"     name="txt_description" required class="textbox" />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_job" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                    <a href="Admin/new_student.php">Blog</a>
                    <a href="Admin/new_student.php">Student</a>
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <?php echo 'Welcom dear, ' . $_SESSION['cat']; ?>
                        <a href="../login.php">Login / Register</a>
                    </div>
                </div>
                <?php
                include './sidemenu.php';
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_universitiess_box();
                //$obj->get_departments_box();
                ?> 
                <div class="parts  no_shade_noBorder item_home_page">
                </div>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
