<div class="parts  side_menu  " id="">

    <a href="select_students.php">Best performers</a>
    
    <a href="new_job.php">Jobs</a>
    &nbsp;  <a class="menuItem" href="../logout.php"> Logout</a>
</div>