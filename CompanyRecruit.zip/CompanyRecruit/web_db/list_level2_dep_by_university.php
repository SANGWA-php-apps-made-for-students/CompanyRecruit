<?php

class multi_values {

    function get_department_by_university_box($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select  department.department_id,  department.name 
                from department 
                join university on university.university_id=department.university
                               where university.university_id=:uniid  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute(array(":uniid" => $id));
        while ($row = $stmt->fetch()) {
            echo '<div class="parts full_center_two_h heit_free res_item_dep'
            . ' no_paddin_shade_no_Border margin_free"><span id="department_id_box" class="off">' . $row['department_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="../Admin/web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="../Admin/web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
