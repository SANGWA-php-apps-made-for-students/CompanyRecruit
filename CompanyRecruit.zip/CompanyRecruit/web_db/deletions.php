<?php 
class deletions{


 function deleteFrom_university( $university_id){
$con = new dbconnection();
$con->con_users();
$query="delete from university where university_id ='$university_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_student( $student_id){
$con = new dbconnection();
$con->con_users();
$query="delete from student where student_id ='$student_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_job( $job_id){
$con = new dbconnection();
$con->con_users();
$query="delete from job where job_id ='$job_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_subject( $subject_id){
$con = new dbconnection();
$con->con_users();
$query="delete from subject where subject_id ='$subject_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_class( $class_id){
$con = new dbconnection();
$con->con_users();
$query="delete from class where class_id ='$class_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_year( $year_id){
$con = new dbconnection();
$con->con_users();
$query="delete from year where year_id ='$year_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_account( $account_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account where account_id ='$account_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account_category where account_category_id ='$account_category_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_test( $test_id){
$con = new dbconnection();
$con->con_users();
$query="delete from test where test_id ='$test_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


}

