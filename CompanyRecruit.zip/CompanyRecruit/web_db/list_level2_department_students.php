<?php

class multi_values {

    function get_department_by_university($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    department.department_id,  department.name as dep,  department.university,  university.name 
                from department  
                join university on university.university_id=department.university
                where university.university_id=:id group by department_id ";
        ?>
        <!--<div class="parts"></div>-->  
        <table class="new_data_table_execpt margin_free" id="table_one">
            <thead>
            <td>Department ID</td>
            <td>University ID</td> 
            <td>University Name</td>
            <td> Department Name</td> 
        </thead>
        <?php
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute(array(":id" => $id));
        while ($row = $stmt->fetch()) {
            ?>
            <tr>
                <td><?php echo $row['department_id']; ?>  </td>
                <td><?php echo $row['university']; ?>  </td>
                <td><?php echo $row['name']; ?>  </td>
                <td>
                    <a href="#" class="link_view_details" value="<?php echo $row['department_id'] ?>">
                        <?php echo $row['dep']; ?> </a> 
                </td>
            </tr>
        <?php }
        ?></table><?php
    }

}
?>
<html>
    <head>
        <title>title</title>
        <style>
            #table_one{
                border-collapse: collapse;
            }
            #table_one thead{
                background-color: #3a30a0;
                color: #fff;
            }
            tr:hover{
                background-color: #aec2c6;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <!--<script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>-->
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                var uni = '';
                var dep = '';
                try {
                    $('#table_one').find('tr').click(function () {
                        var row = $(this).find('td:first').text();
                        uni = $(this).find("td").eq(1).html();
                        dep = $(this).find('td').eq(0).html();
                        //$('#university_id').val('the row: ' + row + ' the second ' + uni);
                        $('#university_id').val(uni);
                        $('#department_id').val(dep);
                        var year_by_department = dep;
                        var both_dep_uni = 'my';
                        $.post('../Admin/handler.php', {both_dep_uni: both_dep_uni, uni: uni, dep: dep}, function (data) {
                            $('.item_home_page').html(data);
                        });

                        $('#table_one').find('tr').css('background-color', 'transparent');
                        $(this).css('background', '#aec2c6');

                    });
                } catch (err) {
                    alert(err.message);
                }
            });
        </script>
    </body>
</html>
<?php

function get_students_vs_departments() {
    require_once('../web_db/connection.php');
    $database = new dbconnection();
    $db = $database->openConnection();
    $sql = "select department.department_id,  department.name,  university.name,  university.type,  student.name,  student.last_name
                from department
                join university on department.university = university.university_id 
                join university on student.university = university.university_id 
                join department on student.department = department.department_id 
               ";
    ?>
    <table class="new_data_table">
        <thead><tr><td> department_id </td><td> name </td><td> name </td><td> type </td><td> name </td><td> last_name </td>
            </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                <td>        <?php echo $row['department_id']; ?> </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['type']; ?> </td>
                <td>        <?php echo $row['name']; ?> </td>
                <td>        <?php echo $row['last_name']; ?> </td>
            </tr>
        <?php } ?></table>
    <?php
}
