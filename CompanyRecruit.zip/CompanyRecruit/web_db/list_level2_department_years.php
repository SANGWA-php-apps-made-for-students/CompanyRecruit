<?php

class multi_values {
    function get_year_by_department() {
        
    }
}
?>
<html>
    <head>
        <title>title</title>
        <style>
             #table_one{
                border-collapse: collapse;
            }
            #table_one thead{
                background-color: #3a30a0;color: #fff;
            }
            tr:hover{
                background-color: #aec2c6;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                try {
                    $('#table_one').find('tr').click(function () {
                        var row = $(this).find('td:first').text();
                        var uni = $(this).find("td").eq(1).html();
//                        $('#university_id').val('the row: ' + row + ' the second ' + uni);
                        $('#university_id').val(uni);
                    });
                } catch (err) {
                    alert(err.message);
                }
            });
        </script>
    </body>
</html>
