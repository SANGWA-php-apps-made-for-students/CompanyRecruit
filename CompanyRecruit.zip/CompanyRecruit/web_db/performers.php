<?php

class multi_values {

    function get_tests_by_uni_dep($dep, $uni) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   test.subject,  test.date,  test.subject,  test.maximum_marks, 
                test.student,student.name as st_name,  test.university,  test.department, 
                subject.name as subj,  department.name as depa,university.name as un_name                                 from test
                join subject on test.subject = subject.subject_id 
                join student on test.student = student.student_id 
                join university on test.university = university.university_id 
                join department on test.department = department.department_id
                where university.university_id=:uni and department.department_id=:dep";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute(array(":dep" => $dep, ":uni" => $uni));
        ?>
<table id="table_one" class="tests_table_performers"><thead>
                <tr>
                    <td>Subject</td>
                    <td>date</td>
                    <td>Maximum marks</td>
                    <td>Student ID</td>
                    <td>Student Name</td>
                    <td>University</td>
                    <td>Department ID</td>
                    <td>Subject</td>
                    <td>Department Name</td>
                    <td>University name</td>
                </tr>
            </thead>
        <?php while ($row = $stmt->fetch()) { ?>
                <tr class="clickable_row">
                    <td> <?php echo $row['subject']; ?>  </td>
                    <td> <?php echo $row['date']; ?>  </td>
                    <td> <?php echo $row['maximum_marks']; ?>  </td>
                    <td> <?php echo $row['student']; ?>  </td>
                    <td> <?php echo $row['st_name']; ?>  </td>
                    <td> <?php echo $row['university']; ?>  </td>
                    <td> <?php echo $row['department']; ?>  </td>
                    <td> <?php echo $row['subj']; ?>  </td>
                    <td> <?php echo $row['depa']; ?>  </td>
                    <td> <?php echo $row['un_name']; ?>  </td>
                </tr>
        <?php } ?></table><?php
    }

}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title><style>
            #table_one{
                border-collapse: collapse;
            }
            #table_one thead{
                background-color: #3a30a0;
                color: #fff;
            }
            tr:hover{
                background-color: #aec2c6;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
         
        
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
