<?php
 require_once '../web_db/connection.php'; 
class multi_values{


 function update_university( $name){
$con = new dbconnection();
$con->con_users();

$query="update university  set name= '$name'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_student( $name, $last_name, $gender){
$con = new dbconnection();
$con->con_users();

$query="update student  set name= '$name', last_name= '$last_name', gender= '$gender'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_job( $name, $condition){
$con = new dbconnection();
$con->con_users();

$query="update job  set name= '$name', condition= '$condition'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_subject( $name, $class, $year){
$con = new dbconnection();
$con->con_users();

$query="update subject  set name= '$name', class= '$class', year= '$year'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_class( $nummber, $total){
$con = new dbconnection();
$con->con_users();

$query="update class  set nummber= '$nummber', total= '$total'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_year( ){
$con = new dbconnection();
$con->con_users();

$query="update year  set ";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_account( $username, $password, $account_category){
$con = new dbconnection();
$con->con_users();

$query="update account  set username= '$username', password= '$password', account_category= '$account_category'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_account_category( $name){
$con = new dbconnection();
$con->con_users();

$query="update account_category  set name= '$name'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_test( $subject, $maximum_marks, $date, $student){
$con = new dbconnection();
$con->con_users();

$query="update test  set subject= '$subject', maximum_marks= '$maximum_marks', date= '$date', student= '$student'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}

}

