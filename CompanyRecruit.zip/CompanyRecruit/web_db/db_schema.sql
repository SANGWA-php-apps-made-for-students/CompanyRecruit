
--
-- Table structure for table `university`
--

CREATE TABLE IF NOT EXISTS `university` (
`university_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`university_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
`student_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 

,PRIMARY KEY (`student_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
`job_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`condition`     VARCHAR(60) 

,PRIMARY KEY (`job_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
`subject_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`subject_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
`class_id`     int(11) NOT NULL AUTO_INCREMENT 
,`nummber`     VARCHAR(60) 

,PRIMARY KEY (`class_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `year`
--

CREATE TABLE IF NOT EXISTS `year` (
`year_id`     int(11) NOT NULL AUTO_INCREMENT 

,PRIMARY KEY (`year_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
`test_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 

,PRIMARY KEY (`test_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

