<?php

function get_id_user_category($category) {
    $userid = 0;

    $database = new dbconnection();
    $sql = "select    account_category.account_category_id from account_category where account_category.name=:name";
    $stmt = $database->openConnection()->prepare($sql);
    $stmt->bindValue(':name', $category);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['account_category_id'];
    return $userid;
}

class new_values {

    function new_university($name, $type, $account) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into university values(:university_id, :name,  :type,  :account)");
        $stm->execute(array(':university_id' => 0, ':name' => $name, ':type' => $type, ':account' => $account));
    }
    function new_student($name, $last_name, $gender, $university,$department,$last_acc) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into student values(:student_id, :name,  :last_name,  :gender, :university, :department, :account)");
        $stm->execute(array(':student_id' => 0, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender,  ':university' => $university, ':department' => $department, ':account' => $last_acc ));
    }

    function new_subject($name, $university) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into subject values(:subject_id, :name, :university)");
        $stm->execute(array(':subject_id' => 0, ':name' => $name, ':university' => $university));
    }

    function new_class($nummber, $total, $year) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into class values(:class_id, :nummber,  :total,:year)");
        $stm->execute(array(':class_id' => 0, ':nummber' => $nummber, ':total' => $total, ':year' => $year
        ));
    }

    function new_year($number, $department) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into year values(:year_id,:number, :department)");
        $stm->execute(array(':year_id' => 0, ':number' => $number, ':department' => $department));
    }

    function new_account($username, $password, $account_category) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category));
    }

    function new_account_category($name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name
        ));
    }

    function new_test($subject, $maximum_marks, $date, $student, $marks, $university, $dep) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into test values(:test_id, :subject,  :maximum_marks,  :date,  :student,:marks,:university, :department)");
        $stm->execute(array(':test_id' => 0, ':subject' => $subject, ':maximum_marks' => $maximum_marks, ':date' => $date, ':student' => $student, ':marks' => $marks, ':university' => $university, ':department' => $dep
        ));
    }

    function new_department($name, $university) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into department values(:department_id ,:name, :university)");
        $stm->execute(array(':department_id' => 0, ':name' => $name, ':university' => $university));
    }

    function new_company($name, $account, $address) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into company values(:company_id, :name,  :address,  :account)");
        $stm->execute(array(':company_id' => 0, ':name' => $name, ':address' => $address, ':account' => $account
        ));
    }

    function new_job($name, $student, $school_name, $description,$account) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into job values(:job_id, :name,  :student,  :school_name,  :description, :account)");
        $stm->execute(array(':job_id' => 0, ':name' => $name, ':student' => $student, ':school_name' => $school_name, ':description' => $description, ':account' => $account
        ));
    }
    //other methods
}