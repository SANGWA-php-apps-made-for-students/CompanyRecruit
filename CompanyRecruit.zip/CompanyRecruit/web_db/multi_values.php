<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_university() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from university";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> Type </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>  <?php echo $row['name']; ?>   </td>
                    <td>  <?php echo $row['type']; ?>   </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_student() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select student.student_id,   university.name,  university.type,
                university.account,    student.name st, 
                student.last_name,  student.gender,  student.university,  department.name
               from department
               join student on student.department = department.department_id 
               join university on student.university = university.university_id ;";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Student ID </td>
                    <td> University ID </td>   <td> University type </td>
                    <td> Student Name </td>
                    <td> Student Last name </td>
                    <td> Gender </td>

                    <td> Department </td>

                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['student_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['type']; ?>
                    </td>

                    <td>
                        <?php echo $row['st']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_job() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from job";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> condition </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['condition']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_subject() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from subject";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Subject ID </td>
                    <td> Name </td>
                    <td> University </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['subject_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['university']; ?>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_class() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from class";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> nummber </td>
                    <td> total </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['nummber']; ?>
                    </td>
                    <td>
                        <?php echo $row['total']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_year() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    year.name,  year.department,  department.name as dep
                from year 
                join department on department.department_id=year.department";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td>year</td>
                    <td>Department ID</td>
                    <td>Department name</td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['department']; ?></td>
                    <td><?php echo $row['dep']; ?></td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_account() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account.username,  account.password,account_category.name as cat  from account  join account_category on account.account_category = account_category.account_category_id ";
        ?>
        <table class="new_data_table">
            <thead>
                <tr>
                    <td> username </td>
                    <td> password </td>
                    <td> account_category </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['cat']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_account_category() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_test() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from test";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Test ID </td>
                    <td> subject </td>
                    <td> maximum_marks </td>
                    <td> date </td>
                    <td> student </td>
                    <td> Marks </td>
                    <td> University </td>
                    <td> Department </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['test_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['subject']; ?>
                    </td>
                    <td>
                        <?php echo $row['maximum_marks']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['student']; ?>
                    </td><td>
                        <?php echo $row['marks_got']; ?>
                    </td>
                    </td>
                    <td>                <?php echo $row['university']; ?>
                    <td>                <?php echo $row['department']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_department() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    department.name as dep,  department.university,  university.name,  university.type 
                    from department 
                    join university on university.university_id=department.university";
        ?>
        <table class="new_data_table">
            <thead><tr><td> Department </td>                     <td> University ID </td>                       <td> University Name </td>                       <td> Type </td>                   </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td> <?php echo $row['dep']; ?>                    </td>
                    <td> <?php echo $row['university']; ?>                    </td>
                    <td> <?php echo $row['name']; ?>                    </td>
                    <td> <?php echo $row['type']; ?>                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function list_company() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from company";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> account </td>
                    <td> address </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['address']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_user_category_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category_id,   account_category.name from account_category";
        ?>
        <select name="txt_account_category" class="textbox combo_user_cat"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_userid_by_Acc_cat($name) {
        $userid = 0;
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select     account_category_id from  account_category    where   name = :name";
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        return $userid;
    }

    //get the classes in combo
    function get_classes_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select class.class_id,   class.nummber from class";
        ?>
        <select class="textbox cbo_class"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['class_id'] . ">" . $row['nummber'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //get the year in combo
    function get_years_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    distinct  year.year_id,  year.name from year";
        ?>
        <select class="textbox cbo_year"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['year.year_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //get the students in combo
    function get_students_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    student.student_id,  student.name from student";
        ?>
        <select class="textbox cbo_student"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['student.student_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //get the subject in combo
    function get_subjeccts_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    subject.subject_id,  subject.name from subject";
        ?>
        <select class="textbox cbo_subject"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['subject.subject_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_departments_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    department.department_id,  department.name from department";
        ?>
        <select class="textbox cbo_department"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['department.department_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_universities_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  university.university_id,  university.name from university  ";
        ?>
        <select class="textbox cbo_university"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['department.university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    //get ids by names
    function get_classid_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    class.class_id from class where class.nummber=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['class_id'];
        echo $userid;
    }

    //get the year in combo
    function get_years_id_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select      year.year_id from year where year.name=name";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['year_id'];
        echo $userid;
    }

    //get the students in combo
    function get_students__id_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    student.student_id from student where student.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['student_id'];
        echo $userid;
    }

    //get the subject in combo
    function get_subjecct_id_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    subject.subject_id     from subject where subject.name=:name";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['subject_id'];
        echo $userid;
    }

    //get the department id in combo
    function get_department_id_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();

        $sql = "select    department.department_id from department where  department.name=:name  ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['department_id'];
        echo $userid;
    }

    //get the department id in combo
    function get_universityt_id_by_name_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    university.university_id from university where   university.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        echo $userid;
    }

    //home selections
    function get_departments_box() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    department.department_id, department.name,    department.university  
                from department 
                join university on university.university_id=department.university";
        ?>
        <!--<div class="parts"></div>-->   
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts res_item_department"><span class="off">' . $row['department_id'] . '</span>' . $row['name'] . '</div>';
        }
    }

    function get_universitiess_box() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select    department.department_id, department.name,university.name as id,    department.university  
                from department 
                join university on university.university_id=department.university group by university.name";
        ?>
        <!--<div class="parts"></div>-->   
        <?php
        foreach ($db->query($sql) as $row) {
            echo '<div class="parts res_item_university"><span class="off">' . $row['university'] . '</span>' . $row['id'] . '</div>';
        }
    }

    function get_department_by_university($id) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    department.department_id,  department.name as dep,  department.university,  university.name 
                from department 
                join university on university.university_id=department.university
                where university.university_id=:id ";
        ?>
        <!--<div class="parts"></div>-->  
        <table class="new_data_table margin_free">
            <thead>
                <tr><td>Department ID</td>
                    <td>Department Name</td>
                    <td>University ID</td>
                    <td>University Name </td> <td>View </td>
                </tr>
            </thead>
            <?php
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->execute(array(":id" => $id));
            while ($row = $stmt->fetch()) {
                ?>
                <tr>
                    <td><?php echo $row['department_id']; ?>  </td>
                    <td><?php echo $row['dep']; ?>  </td>
                    <td><?php echo $row['university']; ?>  </td>
                    <td><?php echo $row['name']; ?>  </td>
                    <td><a href="#" class="link_view_details">View</a> </td>
                </tr>
            <?php }
            ?></table><?php
    }

    function search_department_exists_by_dep_name($id, $name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select     university.university_id from department join university on university.university_id=department.university
                    where university.university_id =:id  and department.name=:name";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['university_id'];
        return $userid;
    }

    function get_last_account() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account.account_id from account order by account.account_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_id'];
        return $userid;
    }

    function get_subjet_by_university($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = " select  university.university_id, university.name
                    from subject    
                    join university on subject.university = university.university_id
                    where university.university_id=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        ?>
        <select class="textbox cbo_subject">   <option></option>
            <?php
            foreach ($stmt->query($sql) as $row) {
                echo "<option value=" . $row['university.university_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_su_by_u($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select  subject.subject_id, subject.name
                    from subject    
                    join university on subject.university = university.university_id
                    where university.university_id=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        ?>
        <select class="textbox cbo_subject">   <option></option>
            <?php
            while ($row = $stmt->fetch()) {
                echo "<option value=" . $row['subject_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_department_by_university_in_combo($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   department.department_id,  department.name 
                from department 
                join university on department.university = university.university_id 
                join account on university.account = account.account_id 
                where university.university_id =:university_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':university_id', $name);
        $stmt->execute();
        ?>
        <select class="textbox cbo_department">   <option></option>
            <?php
            while ($row = $stmt->fetch()) {
                echo "<option value=" . $row['department_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_jobs() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   job.job_id,  job.name,  job.school_name,  job.description,  student.name,  student.last_name
             from job
             join student on job.student = student.student_id      ";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr><td> job_id </td><td> name </td><td> school_name </td><td> description </td><td> name </td><td> last_name </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?>
                <tr> 
                    <td><?php echo $row['job_id']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['school_name']; ?> </td>
                    <td><?php echo $row['description']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_jobs_for_me($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   job.job_id,  job.name,  job.school_name,  job.description,  student.name,  student.last_name
             from job
             join student on job.student = student.student_id  where job.account=:account    ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr><td> job_id </td><td> name </td><td> school_name </td><td> description </td><td> name </td><td> last_name </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?>
                <tr> 
                    <td><?php echo $row['job_id']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['school_name']; ?> </td>
                    <td><?php echo $row['description']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_student_selected() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   student.student_id,  student.name,  student.last_name,  student.gender,  student.university,    department.name
             from student  join department on student.department = department.department_id         ";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr><td> student_id </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> university </td>
                    <td> department </td>
                    <td> name </td>
                    <td> Option </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td><?php echo $row['student_id']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                    <td><?php echo $row['gender']; ?> </td>
                    <td><?php echo $row['university']; ?> </td>
                    <td><?php echo $row['department']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><a href="#" class="selector_link"   value="<?php echo $row['student_id']; ?>" style="color: #000066;" >Select</a>  </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_selectable_students() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   student.student_id,  student.name,  student.last_name, 
                    student.gender,  student.department,  department.name,  university.name as uni
                 from student
                 join university on student.university = university.university_id 
                 join department on student.department = department.department_id ";
        ?>
        <table class="new_data_table" id="seletable_student_table">
            <thead><tr><td> student_id </td><td> name </td><td> last_name </td><td> gender </td><td> department </td><td> name </td><td> name </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td><?php echo $row['student_id']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                    <td><?php echo $row['gender']; ?> </td>
                    <td><?php echo $row['department']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['uni']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_department_list() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select department.department_id,  department.name,  university.name as uni
                from department
                join university on department.university = university.university_id 
               ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> department_id </td><td> name </td><td> name </td>
                </tr></thead>
        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td><?php echo $row['department_id']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['uni']; ?> </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_subject_list($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();

        $sql = "select   subject.subject_id,  subject.name as sub,  university.name
         from subject
         join university on subject.university = university.university_id 
         where  university.account = :account       ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> subject_id </td><td> name </td> 
                </tr></thead>

        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td>        <?php echo $row['subject_id']; ?> </td>

                    <td>        <?php echo $row['sub']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_test_list() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   test.test_id,  test.maximum_marks,  
            test.date,test.marks_got,  student.name as stu,  student.last_name,  
            student.gender,  university.name, subject.name as subj
            from test
            join subject on test.subject = subject.subject_id 
            join student on test.student = student.student_id 
            join university on test.university = university.university_id 
        
         ";
        ?>
        <table class="new_data_table">
            <thead>
                <tr>
                    <td> test id </td>
                    <td> maximum_marks </td>
                    <td> date </td>
                    <td> Marks got </td>
                    <td> Student name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> Subject </td>
                </tr>
            </thead>
        <?php foreach ($db->query($sql) as $row) { ?>
                <tr> 
                    <td><?php echo $row['test_id']; ?> </td>
                    <td><?php echo $row['maximum_marks']; ?> </td>
                    <td><?php echo $row['date']; ?> </td>
                    <td><?php echo $row['marks_got']; ?> </td>
                    <td><?php echo $row['stu']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                    <td><?php echo $row['gender']; ?> </td>
                    <td><?php echo $row['subj']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_lastsubject() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   subject.subject_id from subject order by subject.subject_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['subject_id'];
        return $userid;
    }

    function get_my_jobs($username, $password) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   job.job_id, student.name as stu,  student.last_name,
            job.name,  job.student,
            job.school_name,  job.description
                from job
                join student on job.student = student.student_id 
                join account on student.account = account.account_id  
                where   account.username=:username and account.password=:password ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute(array(':username' => $username, ':password' => $password));
        ?>
        <table class="new_data_table" style="margin-top: 20px;">
            <thead>
                <tr>
                    <td> job_id </td>
                    <td> Graduate name </td>
                    <td> Graduate surname </td>

                    <td> Job title </td>
                    <td> student </td>
                    <td> school_name </td><td> description </td>   
                </tr></thead>
            <?php
                while ($row = $stmt->fetch()) {
                    ?><tr> 
                    <td>        <?php echo $row['job_id']; ?> </td>
                    <td>        <?php echo $row['stu']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['student']; ?> </td>
                    <td>        <?php echo $row['school_name']; ?> </td>
                    <td>        <?php echo $row['description']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

    function get_my_departments($account) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select department.department_id,  department.name as dep,  university.name
         from department
       join university on department.university = university.university_id 
         join account on account.account_id=university.account
         where  university.account = :account ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account', $account);
        $stmt->execute();
        ?>
        <table class="new_data_table">
            <thead><tr><td> department_id </td><td> Department </td><td> University </td>
                </tr></thead>
        <?php while ($row = $stmt->fetch()) { ?><tr> 
                    <td><?php echo $row['department_id']; ?> </td>
                    <td><?php echo $row['dep']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                </tr>
        <?php } ?></table>
        <?php
    }

    function get_students_list() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select job.job_id,  job.name,  job.student,  job.school_name,  job.description,  student.name,  student.last_name,  student.gender,  student.department
         from job
         join student on job.student = student.student_id ";
        ?>
        <table class="new_data_table">
            <thead><tr><td> job_id </td><td> name </td><td> student </td><td> school_name </td><td> description </td><td> name </td><td> last_name </td><td> gender </td><td> department </td>
                </tr></thead>

        <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>        <?php echo $row['job_id']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['student']; ?> </td>
                    <td>        <?php echo $row['school_name']; ?> </td>
                    <td>        <?php echo $row['description']; ?> </td>
                    <td>        <?php echo $row['name']; ?> </td>
                    <td>        <?php echo $row['last_name']; ?> </td>
                    <td>        <?php echo $row['gender']; ?> </td>
                    <td>        <?php echo $row['department']; ?> </td>

                </tr>
        <?php } ?></table>
        <?php
    }

}
