<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="Admin/web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="Admin/web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .link{
                background-color: #24580a;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <form action="testPage.php" method="post">
            <div class="parts eighty_centered">
                Test the table events
            </div>
            <div class="parts eighty_centered">
                <table class="new_data_table" id="thetable"><thead>
                        <tr>
                            <td>NAME</td>
                            <td>LAST NAME</td>
                            <td>OPTION</td>
                        </tr></thead>
                    <tr>
                        <td>Paul</td>
                        <td>HABIMANA</td>
                        <td><a href="#" class="link">View</a></td>
                    </tr>
                    <tr>
                        <td>Peter</td>
                        <td>UWINEZA</td>
                        <td><a href="#" value="my_contents" class="link">View</a></td>
                    </tr>
                </table><div class="parts" id="middle"></div>
            </div>
        </form>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                try {
                    $('.link').click(function () {
                        try {
                            var content = $(this).attr('value');
                            alert('the link has: ' + content);
                        } catch (err) {
                            alert(err.message);
                        }
                    });

                } catch (err) {
                    alert(err.message);
                }





//        $('#thetable').find('tr').find('.link').click(function () {
//                    var row = $(this).find('tr').find('td:first').text();
//                    $('#middle').html('the clicked: ' + row);
//                    // var last_row=$(this).find('tr:last td:first').text();
//                });
            });
        </script>
    </body>
</html>
