<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="home_body">
        <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
            </div> 
            <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                <a href="#">Home</a>
                <a href="aboutus.php">About us</a>
                <a href="contactus.php">Contact us</a>
                <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                    <a href="login.php">Login </a>
                    <a href="register_page.php"> Register</a>

                </div>

            </div>
            <div class="parts full_center_two_h heit_free margin_free">
                <div class="parts fixed_box_5x" id="bg1">

                </div>
                <div class="parts two_fifty_right heit_free no_shade_noBorder">
                    <div class=" parts margin_free full_center_two_h heit_free no_shade_noBorder x_titles">
                        Find Fresh graduates
                    </div>
                    <div class="parts  margin_free full_center_two_h heit_free no_shade_noBorder">
                        Feel free to browse and find your staff from 

                    </div> 
                    <div class=" parts margin_free no_shade_noBorder x_titles">
                        About us  

                    </div>

                    <div class="parts full_center_two_h no_shade_noBorder heit_free">

                        We provide access to all Universities in Rwanda with their newly graduated student. 
                        By accessing them you can request the university the student who are 
                        skilled and ready for jobs.<br/>

                    </div>
                </div>
            </div>
            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder "style="background-color: #000066; color: #fff; text-align: center">
                Copyrights  <?php echo date("Y"); ?>
            </div> 
        </div>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
