<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="univ_reg.php" method="post">

            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="#">Home</a>
                    <a href="../Admin/best_performers.php">Best performers</a>
                    
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <a href="../login.php">Login </a>
                        <a href="../register_page.php">REgister </a>
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free margin_free">
                    <div class="parts fixed_box_5x" id="bg1">
                        <div class="parts  full_center_two_h heit_free margin_free skin">  ADDING NEW UNIVERSITY</div>
                        <table class="new_data_table">
                            <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                            <tr><td>type :</td><td> 
                                    <select name="txt_type">
                                        <option>
                                            Private
                                        </option>
                                        <option>
                                            Public
                                        </option>
                                    </select>
                                </td></tr>
                            <tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" />  </td></tr>
                            <tr><td>password :</td><td> <input type="password"     name="txt_password" required class="textbox"  /> </td></tr>
                            <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_univ" value="Save"/>  </td></tr>
                        </table>
                    </div>

                </div>
            </div>
            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder "style="background-color: #000066; color: #fff; text-align: center">
                Copyrights  <?php echo date("Y"); ?>
            </div> 
        </div> 
    </form>
</body>
</html>
<?php
if (isset($_POST['send_univ'])) {
    require_once '../web_db/new_values.php';

    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_account($username, $password, '2');
    include '../web_db/multi_values.php';
    $obj_mul = new multi_values();
    $last_acc = $obj_mul->get_last_account();
    $name = $_POST['txt_name'];
    $type = $_POST['txt_type'];

    $obj = new new_values();
    $obj->new_university($name, $type, $last_acc);
    ?><script>
        alert('Saved successfully');
    </script>
    <?php
}