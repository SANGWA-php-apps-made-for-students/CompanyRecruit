<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_test'])) {
    try {
        $subject = $_POST['txt_subject_id'];
        $maximum_marks = $_POST['txt_maximum_marks'];
        $date = date("Y-m-d");
        $student = $_POST['txt_student_id'];
        $marks = $_POST['txt_marks'];
        $university = $_SESSION['univ_id'];
        $dep = $_POST['txt_department_id'];
//        echo 'subject: '.$subject.'  max marks: '.$maximum_marks.'  student:'.$student.'  marks:'.$marks.'  univ:'.$university. '  dep:'.$dep;
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_test($subject, $maximum_marks, $date, $student, $marks, $university, $dep);
    } catch (Exception $e) {
        echo $e;
    }
    ?>
    <script>
        alert('Data saved successfully');
    </script>
    <?php
}
?>
<html>
    <head>
        <title>
            test</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>
        <form action="new_test.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="txt_department_id">
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                    <a href="Admin/new_student.php">Blog</a>
                    <a href="Admin/new_student.php">Student</a>
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <a href="../login.php">Login / Register</a>
                    </div>
                </div>
                <?php include './sidemenu.php'; ?>

                <input type="hidden" id="txt_student_id"   name="txt_student_id" />
                <input type="hidden" id="txt_subject_id"   name="txt_subject_id" /> 
                <input type="hidden" id="txt_university_id"   name="txt_university_id"/>
                <span id="d" class="off"></span>
                <input type="hidden" id="txt_department_id"   name="txt_department_id" />
                <div class="parts ">
                    <div class="parts  full_center_two_h heit_free margin_free skin">  ADDING NEW TEST</div>
                    <table class="new_data_table">
                        <tr><td>subject :</td><td>   <?php get_subject_combo(); ?></td></tr>
                        <tr><td>student :</td><td> <?php get_student_combo(); ?>  </td></tr>
                        <tr><td>maximum_marks :</td><td> <input type="text"     name="txt_maximum_marks" required class="textbox"   </td></tr>
                        <tr><td>Marks :</td><td><input type="text" class="textbox" name="txt_marks"> </td></tr>
                        <tr><td>Departments</td>    <td> 
                           <?php get_departments_in_combo(); ?>
                            </td>
                        </tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_test" value="Save"/>  </td></tr>
                    </table>
                </div>
                <div class="parts eighty_centered" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->get_test_list();
                    ?>
                </div> 
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_subject_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $name = $_SESSION['univ_id'];
    $obj->get_su_by_u($name);
}

function get_student_combo() {
    $obj = new multi_values();
    $obj->get_students_combo();
}

function get_departments_in_combo() {
    $obj = new multi_values();
    $obj->get_department_by_university_in_combo($_SESSION['univ_id']);
}

function get_department_combo() {

    $obj = new multi_values();
    $obj->get_departments_combo();
}
