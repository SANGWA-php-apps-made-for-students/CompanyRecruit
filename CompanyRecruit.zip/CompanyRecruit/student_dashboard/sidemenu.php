<div class="parts  side_menu  " id="">
    <!--      <a class="menuItem" href="new_account_category.php">users category</a>   <a class="menuItem" href="new_account.php">Users account</a>
    
    <a class="menuItem" href="new_university.php">University</a>-->
    <a class="menuItem" href="offered_jobs.php">Offered jobs</a>
 
    <!--    <a class="menuItem" href="new_year.php">Years / levels</a>
        <a class="menuItem" href="new_class.php">Classes</a>-->
<!--    <a class="menuItem" href="new_job.php">Companies</a>-->
    <!--<a class="menuItem" href="new_image.php">Manage images</a>-->
  
    <!--    <a class="menuItem" href="new_listing_type.php">Listing types</a>-->
    <!--<a class="menuItem" href="new_profile.php">Profiles</a>-->
    <br/>
    <br/>
    <a  class="menuItem" href="../logout.php"> Logout</a>
</div>