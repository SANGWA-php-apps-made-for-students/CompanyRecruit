<!DOCTYPE html>
<?php
session_start();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_job.php" method="post">
            <input type="hidden" id="txt_student_id" name="txt_student_id">

            <div class="parts abs_full accept_abs off" style="position: absolute; top: 0px; height: 100%; opacity: 0.5;"  id="dialog_students">
            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off" style="opacity: 1; background-color: #fff;" id="dialog_child">
                <?php
//                require_once '../web_db/multi_values.php';
//                $obj_mul = new multi_values();
//                $obj_mul->get_selectable_students();
                ?>
            </div>
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                 
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <a href="login.php">Login </a>
                        <a href="register_page.php">REgister </a>
                    </div>
                </div>

                <div class="parts  full_center_two_h heit_free item_home_page">
<div class="parts box no_paddin_shade_no_Border" id="side_pic3"></div>
                    <div class="parts two_fifty_right heit_free no_shade_noBorder">
                        <a class="menuItem" style="color:#000080;" href="hod/univ_reg.php">Register as university</a>
                        <br/><br/><br/>  <a class="menuItem" style="color:#000080;" href="company/company_reg.php">Register as Company</a>
                    </div>
                </div>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
