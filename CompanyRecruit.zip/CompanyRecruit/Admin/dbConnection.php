<?php

class my_connection {
    function getCon() {
        $db = new PDO('mysql:host=localhost;dbname=company_recruitment;charset=utf8mb4', 'sangwa', 'A.manigu125');
        return $db;
    }
}
