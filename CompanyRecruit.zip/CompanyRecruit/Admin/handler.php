<?php

session_start();
if (isset($_POST['sent'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_userid_by_Acc_cat($_POST['sent']);
    echo $id;
}
if (isset($_POST['prop'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_id_property($_POST['prop']);
    echo $id;
}
if (isset($_POST['prop_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_id_property_type($_POST['prop_type']);
    echo $id;
}

//Here we return totals of the entities
//company
if (isset($_POST['cbo_class'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_classid_by_name_combo($_POST['cbo_class']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['cbo_year'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_years_id_by_name_combo($_POST['cbo_year']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['cbo_student'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_students__id_by_name_combo($_POST['cbo_student']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['cbo_subject'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_subjecct_id_by_name_combo($_POST['cbo_subject']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['cbo_department'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_department_id_by_name_combo($_POST['cbo_department']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['cbo_university'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $res = $obj->get_universityt_id_by_name_combo($_POST['cbo_university']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['box_university'])) {
    require_once '../web_db/list_level2_department_students.php';
    $obj = new multi_values();
    $res = $obj->get_department_by_university($_POST['box_university']);
    // $_SESSION['cell_id'] = $res;
    return $res;
}
if (isset($_POST['year_by_department'])) {
    $university = $_POST['uni'];
    $department = $_POST['year_by_department'];
    echo $university . ' - ' . $department;
    /*
      require_once '../web_db/list_level2_department_years.php';
      $obj = new multi_values();

      $res = $obj->get_year_by_department($_POST['year_by_department']);
      // $_SESSION['cell_id'] = $res;
      return $res; */
}
if (isset($_POST['departments_in_box'])) {
    require_once '../web_db/list_level2_dep_by_university.php';
    $obj = new multi_values();
    $res = $obj->get_department_by_university_box($_POST['departments_in_box']);
    return $res;
}
if (isset($_POST['both_dep_uni'])) {
    require_once '../web_db/performers.php';
    $uni = $_POST['uni'];
    $dep = $_POST['dep'];
       $obj = new multi_values();
     $res = $obj->get_tests_by_uni_dep($dep, $uni);
     return $res;
}

//performers

