<?php

require('fpdf/fpdf.php');

class PDF extends FPDF {

    function Header() {
        $this->SetFont('Times', '', 12);
        $this->SetY(0.25);
        $this->Cell(0, .25, "Recruitment " . $this->PageNo(), 'T', 2, "R");
        //reset Y
        $this->SetY(1);
    }

    function Footer() {
        //This is the footer; it's repeated on each page.
        //enter filename: phpjabber logo, x position: (page width/2)-half the picture size,
        //y position: rough estimate, width, height, filetype, link: click it!
    }

}

//class instantiation
$pdf = new PDF("P", "in", "Letter");
$pdf->SetMargins(.5, 1, 1);
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);


$lipsum1 = "This is the Report of graduates and jobs";
$lipsum2 = "This may be a body";
$lipsum3 = "another p of the body or the footer";


$pdf->SetFillColor(255, 255, 255);
$pdf->SetFont('Times', 'B', 11);

//Cell(float w[,float h[,string txt[,mixed border[,
//int ln[,string align[,boolean fill[,mixed link]]]]]]])

require_once('../web_db/connection.php');
$db = new dbconnection();
$sql = "select job.job_id,  job.name as jb,  job.student,  job.school_name,  job.description,
            student.name as stu,  student.last_name,  student.gender,  student.department
         from job
         join student on job.student = student.student_id ";
$stmt = $db->openConnection()->prepare($sql);
$stmt->execute();
$c=0;
while ($row = $stmt->fetch()) {
    $id = $row['job_id'];
    $uni = $row['school_name'];
    $description = $row['description'];
    $student_name = $row['stu'];
    $last_name = $row['last_name'];
    $gender = $row['gender'];
    $department = $row['department'];
    $description=$row['description'];
   

    $pdf->Write(0.3, "Graduate  name: ".$student_name);
    $pdf->Ln();
    $pdf->Write(0.3, "Last name: ".$last_name);
    $pdf->Ln();
    $pdf->Write(0.3, "Gender: ".$gender);
    $pdf->Ln();
    $pdf->Write(0.3, "University: ".$uni);
    $pdf->Ln();
    $pdf->Write(0.3, "Description: ".$description);
    $pdf->Ln();
       $pdf->Write(0.3, "------------------------------------------------------------------------ ".'');
     
     $pdf->Ln();
    if ($c==3) {
          $pdf->AddPage();
   $c=0;
    }
   $c+=1;
}

$pdf->Output();
