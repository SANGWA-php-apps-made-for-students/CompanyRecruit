<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>  
        <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
            </div> 
            <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                <a href="../index.php">Home</a>
                <a href="#">Best performers</a>
                <a href="Admin/new_student.php">Blog</a>
                <a href="Admin/new_student.php">Student</a>
                
                <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                    <?php echo 'Welcom dear, '.$_SESSION['cat'];  ?>
                    <a href="../login.php">Login / Register</a>
                </div>
            </div>
            <?php include './sidemenu.php'; ?> 
            <div class="parts eighty_centered no_shade_noBorder item_home_page">
            </div>
            <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder"  style="background-color: #000066; color: #fff; text-align: center">Copyrights
                <?php echo date("Y"); ?>
            </div>
        </div>

    </body>
</html>
