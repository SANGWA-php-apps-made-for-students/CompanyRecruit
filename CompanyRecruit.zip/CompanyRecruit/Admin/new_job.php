<!DOCTYPE html>
<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_job'])) {
    $name = $_POST['txt_name'];
    $student = $_POST['txt_student_id'];
    $school_name = $_POST['txt_school_name'];
    $description = $_POST['txt_description'];

    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_job($name, $student, $school_name, $description);
    ?>
    <script>
        aler('Job saved successfully');
    </script>
    <?php
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="new_job.php" method="post">
            <input type="hidden" id="txt_student_id" name="txt_student_id">
            <div class="parts abs_full accept_abs off" style="position: absolute; top: 50px; height: 100%; opacity: 0.5;"  id="dialog_students">
            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy off" style="opacity: 1; background-color: #fff;" id="dialog_child">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_students();
                ?>
            </div>
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                    <a href="Admin/new_student.php">Blog</a>
                    <a href="Admin/new_student.php">Student</a>
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <?php echo 'Welcom dear, ' . $_SESSION['cat']; ?>
                        <a href="../login.php">Login / Register</a>
                    </div>
                </div>
                <?php
                include './sidemenu.php';
                ?>
                <div class="parts   item_home_page no_paddin_shade_no_Border">
                    <div class="parts eighty_centered off saved_dialog">
                        job saved successfully!</div>
                    <div class="parts full_center_two_h heit_free margin_free">  Offered jobs</div>
                    <table class="new_data_table off">
                        <tr><td>Title :</td><td> <input type="text"     name="txt_name" required class="textbox" />  </td></tr>
                        <tr><td>graduate :</td><td><a id="link_select_student" style="color: #000066;" href="#">Choose graduate</a></td></tr>
                        <tr><td>University name :</td><td> <input type="text" id="txt_school_name"    name="txt_school_name" required class="textbox" />  </td></tr>
                        <tr><td>Job description :</td><td> <input type="Textarea"     name="txt_description" required class="textbox" />  </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_job" value="Save"/>  </td></tr>
                    </table>
                    <div class="parts no_paddin_shade_no_Border">
                        <?php
                        require_once '../web_db/multi_values.php';
                        $obj = new multi_values();
                        $obj->get_jobs();
                        ?>
                    </div>
                </div>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
    </body>
</html>
