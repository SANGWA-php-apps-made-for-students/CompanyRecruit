<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/><style>
            #table_one{
                border-collapse: collapse;
            }
            #table_one thead{
                background-color: #3a30a0;
                color: #fff;
            }
            tr:hover{
                background-color: #aec2c6;
                cursor: pointer;
            }
        </style>
    </head>
    <body>
        <form action="best_performers.php" method="post">
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div> 
                <input type="hidden" id="txt_my_uni">
                <span id="d">

                </span>
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                    <a href="#">Best performers</a>
                    <a href="Admin/new_student.php">Blog</a>
                    <a href="Admin/new_student.php">Student</a>
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <a href="../login.php">Login / Register</a>
                    </div>
                </div>
                <?php
                include '../company/sidemenu.php';
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->get_universitiess_box();
                //$obj->get_departments_box();
                ?> 
                <div class="parts eighty_centered no_shade_noBorder item_home_page" style="margin-top: 50px;"  >
                </div>
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder"  style="background-color: #000066; color: #fff; text-align: center">Copyrights
                    <?php echo date("Y"); ?>
                </div>
            </div>
        </div>
    </form> <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/scriptsAddon.js" type="text/javascript"></script>
</body>
</html>
