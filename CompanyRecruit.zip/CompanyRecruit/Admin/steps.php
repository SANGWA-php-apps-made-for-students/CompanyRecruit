<div class="parts eighty_centered margin_free no_paddin_shade_no_Border">
    <a href="new_listing.php"> 
        <div class="parts two_fifty_left heit_free stepItem iconed"><center> 1 Property description</center></div>
    </a>
    <a href="new_price.php">
        <div class="parts two_fifty_left heit_free stepItem iconed" ><center>2 Price</center></div>
    </a>
    <a href="new_image.php">
        <div class="parts iconed two_fifty_left heit_free stepItem "><center>3 Attachments</center></div>           
    </a>
</div>