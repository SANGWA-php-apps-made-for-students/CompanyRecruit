<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_university'])) {

    include '../web_db/multi_values.php';
    $name = $_POST['txt_name'];
    $type = $_POST['txt_type'];
    $acc = $_SESSION['userid'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_university($name, $type, $acc);
    ?>
    <script>
        alert('Data saved successfully');
    </script>
    <?php
}
?>

<html>
    <head>
        <title>
            university</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>   <body>
        <form action="new_university.php" method="post" enctype="multipart/form-data">
            <div class="parts seventy_centered no_paddin_shade_no_Border reverse_border top_off_x">
                <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder " id="my_title">
                </div>
                <div class="parts full_center_two_h no_shade_noBorder heit_free margin_free " id="my_menu">
                    <a href="../index.php">Home</a>
                    <a href="#">Best performers</a>
                    <a href="Admin/new_student.php">Blog</a>
                    <a href="Admin/new_student.php">Student</a>
                    <div class=" parts two_fifty_right heit_free no_paddin_shade_no_Border">
                        <a href="../login.php">Login / Register</a>
                    </div>
                </div>
                <?php include './sidemenu.php'; ?>

                <div class="parts ">

                    <div class="parts  full_center_two_h heit_free margin_free skin">  ADDING NEW UNIVERSITY</div>
                    <table class="new_data_table">
                        <tr><td>name :</td><td> <input type="text"     name="txt_name" required class="textbox"   </td></tr>
                        <tr><td>type :</td><td>
                                <select name="txt_type">
                                    <option>
                                        Private
                                    </option>
                                    <option>
                                        Public
                                    </option>
                                </select>
                            </td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_university" value="Save"/>  </td></tr>
                    </table>
                </div>

                <div class="parts eighty_centered" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->list_university();
                    ?>

                </div>
        </form></div>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
