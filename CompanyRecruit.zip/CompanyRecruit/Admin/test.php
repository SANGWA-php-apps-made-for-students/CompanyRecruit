<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    subject.subject_id     from subject where subject.name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', 'programming');
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['subject_id'];
        echo $userid;
        ?>
    </body>
</html>
