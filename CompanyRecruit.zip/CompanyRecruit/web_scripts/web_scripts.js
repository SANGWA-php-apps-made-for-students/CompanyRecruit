var slideCounter = 0;

$(document).ready(function (){
     slideShow();
});
function slideShow() {
    setTimeout(function () {
        slideCounter += 1;
        if (slideCounter == 6) {
            $('.slide_pics').fadeOut(450);
            $('#pic1').fadeIn(450);
        } else if (slideCounter == 11) {
            $('.slide_pics').fadeOut(450);
            $('#pic2').fadeIn(450);
        } else if (slideCounter == 17) {
            $('.slide_pics').fadeOut(450);
            $('#pic3').fadeIn(450);
        } else if (slideCounter == 24) {
            $('.slide_pics').fadeOut(450);
            $('#pic4').fadeIn(450);
        } else if (slideCounter == 31) {
            $('.slide_pics').fadeOut(450);
            $('#pic5').fadeIn(450);
        } else if (slideCounter == 38) {
            $('.slide_pics').fadeOut(450);
            $('#pic6').fadeIn(450);
        } else if (slideCounter == 46) {
            $('.slide_pics').fadeOut(450);
            $('#pic7').fadeIn(450);
        } else if (slideCounter == 53) {
            $('.slide_pics').fadeOut(450);
            $('#pic8').fadeIn(450);
            slideCounter = 0;
        }
        slideShow();
    }, 1000);
}