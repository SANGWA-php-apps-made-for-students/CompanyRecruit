var lat, lng;
var marker;
$(document).ready(function () {
    try {
        get_department_id_box();


        get_home_selected_menu();
        select_butn_color_changer('#listing_typeid', '.list_typebtn');
        icon_setter('.stepItem');// fund on list type
        getAndSend_id_by_name_from_combo('sent', '.combo_user_cat', '../Admin/handler.php', '#acc_typeid');
        //getAndSend_id_by_name_from_combo('sent', '.combo_property', '../Admin/handler.php', '#txt_propertyid');

        //company
        get_class_id_combo();
        get_year_id_combo();
        get_student_id_combo();
        get_subject_id_combo();
        get_department_id_combo();
        get_university_id_combo();
        get_university_id_box();
        get_details_link();

        get_deaprtments_by_university_combo();
        get_dep_click();
        get_student_showed();
        get_hide_selectable_students();
        get_students_selected();
        get_students_by_row();
        get_clickable_row();
    } catch (err) {
        alert(err.message);
    }

});
function get_home_selected_menu() {
    $('#for_sale').click(function () {
        $('#menu_selection').val('for_sale');
    });
    $('#for_rent').click(function () {
        $('#menu_selection').val('for_rent');
    });
    $('#furnished').click(function () {
        $('#menu_selection').val('furnished');
    });
    $('.home_menu').click(function () {
        $('.home_menu').css('background-color', '#5fd4f6');
        $(this).css('background-color', '#2c7489').css('color', '#fff');
    });
}
function select_butn_color_changer(hidn_field, btn) {// this specifies the button selected by color and puts the id in the hidden field
    $(btn).click(function () {
        var id = $(this).children('span:first').html();
        $(btn).removeClass('ok_ticked');
        $(this).addClass('ok_ticked');
        $(hidn_field).val(id);
    });
}
function icon_setter(btn) {
    $(btn).removeClass('ok_ticked');
    $(this).addClass('ok_ticked');
}
function getAndSend_id_by_name_from_combo(sent, combo, path, callBack_value_textfield) {
    try {
        $(combo).change(function () {
            sent = $(combo + ' option:selected').text();
            $.post(path, {sent: sent}, function (data) {
                $(callBack_value_textfield).val(data);

            });

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_property_id_combo() {
    try {
        $('.combo_property').change(function () {
            var prop = $('.combo_property option:selected').text();
            $.post('../Admin/handler.php', {prop: prop}, function (data) {
                $('#txt_propertyid').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_property_type_id_combo() {
    try {
        $('.combo_property_type').change(function () {
            var prop_type = $('.combo_property_type option:selected').text();
            $.post('../Admin/handler.php', {prop_type: prop_type}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_property_type_id').val($('#d').text());
                $('#prop_name').val(prop_type);
            });
        });

        $('.res_item').click(function () {
            var prop_cat = $(this).html();
            $.post('../Admin/handler.php', {prop_cat: prop_cat}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_property_cat_id').val($('#d').text());
            });
        });


    } catch (err) {
        alert(err.message);
    }


}
function get_provinces_combo() {
    try {
        $('.combo_province').change(function () {
            var province = $('.combo_province option:selected').text();
            $.post('../Admin/handler.php', {province: province}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_province_id').val($('#d').text());
            });
        });
        $('.res_item').click(function () {
            var prop_cat = $(this).html();
            $.post('../Admin/handler.php', {prop_cat: prop_cat}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_property_cat_id').val($('#d').text());
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_districts_combo() {//this is found on location form
    $('.combo_district').change(function () {
        var district = $('.combo_district option:selected').text();
        $.post('../Admin/handler.php', {district: district}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_district_id').val($('#d').text());
        });
    });

    //combo_district
}
function get_sectors_combo() {
    $('.combo_sectors').change(function () {
        var sector = $('.combo_sectors option:selected').text();
        $.post('../Admin/handler.php', {sector: sector}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_sector_id').val($('#d').text());
        });
    });

    //combo_district
}
function get_districts_by_province() {
    $('.combo_province2').change(function () {
        var district_by_prov = $('.combo_province2 option:selected').text();
        var province = $('.combo_province2 option:selected').text();
        $.post('../Admin/handler.php', {district_by_prov: district_by_prov}, function (data) {
            $('#districts_res').show().html(data);
        });
        $.post('../Admin/handler.php', {province: province}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_province_id').val($('#d').text());
        });
    });
}
function get_prop_cat_byprop_type() {
    $('.gen_cat').change(function () {
        var prop_type_cat = $('.gen_cat option:selected').text();//here we mean that we are looking for the property category
        $.post('../Admin/handler.php', {prop_type_cat: prop_type_cat}, function (data) {
            $('#my_cat_res').show().html(data);
            $('#property_subCat_label').show();
        });
    });
}
function res_item_selected() {
    $('.res_item').click(function () {
        try {
            $('.res_item').css('background', 'none').css('color', '#000080');
            $(this).css('background', '#000080').css('color', '#fff');
            //get the id of the clicked item

        } catch (err) {
            alert(err.message);
        }
    });
    $('.res_item_districts').click(function () {
        try {
            $('.res_item_districts').css('background', 'none').css('color', '#000080');
            $(this).css('background', '#000080').css('color', '#fff');
            //get the id of the clicked item
            var district = $(this).html();
            $.post('../Admin/handler.php', {district: district}, function (data) {
                var dd = $('#d').html(data);
                $('#txt_district_id').val($('#d').text());
            });
        } catch (err) {
            alert(err.message);
        }
    });
}
function get_sectors_by_districts() {
    $('.res_item_districts').click(function () {
        var sectors_by_district = $(this).html();
        $.post('../Admin/handler.php', {sectors_by_district: sectors_by_district}, function (data) {
//            $('#districts_res').show().html(data);
            $('#res_sector_box').html(data);

        });
    });

    //
}
function get_cells_by_sector() {
    $('.res_item_sectors').click(function () {
        var cell_by_sector = $(this).html();
        $.post('../Admin/handler.php', {cell_by_sector: cell_by_sector}, function (data) {
            //$('#districts_res').show().html(data);
            $('#res_cell_box').html(data);

        });
    });
}
function get_selected_cell() {
    $('.res_item_cells').click(function () {
        var cell_id = $(this).html();
        $.post('../Admin/handler.php', {cell_id: cell_id}, function (data) {
            var dd = $('#d').html(data);
            $('#txt_cell_id').val($('#d').text());

        });

    });
}
function map_loc_link() {
    $('#map_loc_link').click(function () {
        //get full
        $('#map_box').show();
        $('#map').show();
        $('#label').show();
        $('#marker_loc').show();
        //show dialog
        //,user-scalable=no'
        get_map_loc();
    });
    $('#map_box').click(function () {

        $(this).hide();
        $('#map_box').hide();
        $('#map').hide();
        $('#label').hide();
        $('#marker_loc').hide();

    });
    $('#marker_loc').click(function () {
        try {
            $('#txt_loc_lat').val(lat);
            $('#txt_loc_lng').val(lng);
            $(this).hide();
            $('#map_box').hide();
            $('#map').hide();
            $('#label').hide();
            $('#marker_loc').hide();
        } catch (err) {
            alert(err.message);
        }


    });
}
function get_map_loc() {
    navigator.geolocation.getCurrentPosition(function (position) {
        $("#result").html("Found your location <br />Lat : " + position.coords.latitude + " </br>Lang :" + position.coords.longitude);
        var myLatLng = {lat: position.coords.latitude, lng: position.coords.longitude};
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
            center: myLatLng
        });
        marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Me',
            draggable: true
        });
        google.maps.event.addListener(marker, 'drag', function (evt) {
            lat = marker.getPosition().lat();
            lng = marker.getPosition().lng();
            $('#label').html(lat + ' -- ' + lng);
        });
        lat = position.coords.latitude;
        var long = position.coords.longitude;
        $.ajax({url: 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' + lat + ',' + long + '&sensor=true',
            success: function (data) {
                $('.text_loc').val(data.results[0].formatted_address);
                //alert(data.results[0].formatted_address);
                /*or you could iterate the components for only the city and state*/
            }
        });
    });

//    $('#marker_loc').click(function () {
//        lat = marker.getPosition().lat();
//        lng = marker.getPosition().lng();
//        alert('the marker at:' + lng + ' ' + lat);
//    });
}
function get_listing_type() {
    $('.list_typebtn').click(function () {
        var listi_typeid = $(this).children('span:first').html();
        $.post('../Admin/handler.php', {listi_typeid: listi_typeid}, function (data) {
        }).complete(function () {
            window.location.href = "http://localhost/REstate/Admin/new_listing.php";
        });
    });
}
//company

function get_class_id_combo() {
    try {
        $('.cbo_class').change(function () {
            var cbo_class = $('.cbo_class option:selected').text();
            $.post('../Admin/handler.php', {cbo_class: cbo_class}, function (data) {
                $('#txt_class_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_year_id_combo() {
    try {
        $('.cbo_year').change(function () {
            var cbo_year = $('.cbo_year option:selected').text();
            $.post('../Admin/handler.php', {cbo_year: cbo_year}, function (data) {
                $('#txt_year_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_student_id_combo() {
    try {
        $('.cbo_student').change(function () {
            var cbo_student = $('.cbo_student option:selected').text();
            $.post('../Admin/handler.php', {cbo_student: cbo_student}, function (data) {
                $('#txt_student_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_subject_id_combo() {
    try {
        $('.cbo_subject').change(function () {
            var cbo_subject = $('.cbo_subject option:selected').text();
            $.post('../Admin/handler.php', {cbo_subject: cbo_subject}, function (data) {
                $('#txt_subject_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_department_id_combo() {
    try {
        $('.cbo_department').change(function () {
            var cbo_department = $('.cbo_department option:selected').val();
            $.post('../Admin/handler.php', {cbo_department: cbo_department}, function (data) {
                var id = cbo_department.trim();
                $('#txt_department_id').val(id);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_university_id_combo() {
    try {
        $('.cbo_university').change(function () {
            var cbo_university = $('.cbo_university option:selected').text();
            $.post('../Admin/handler.php', {cbo_university: cbo_university}, function (data) {
                $('#d').html(data);
                $('#txt_university_id').val($('#d').text());
            }).complete(function () {
                var departments_in_box = $('#txt_university_id').val();
                $.post('../Admin/handler.php', {departments_in_box: departments_in_box}, function (data) {
                    $('.my_res_dep').html(data);
                });
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_dep_click() {
    $('.res_item_dep').unbind('click').click(function () {
        $('.res_item_dep').css('background', 'none').css('color', '#000080');
        $(this).css('background', '#000080').css('color', '#fff');
        var dep_id = $(this).children('span:first').html();
        $('#txt_department_id').val(dep_id);
    });
}
function get_university_id_box() {
    try {
        $('.res_item_university').click(function () {
            var box_university = $(this).children('span:first').html();
            $.post('../Admin/handler.php', {box_university: box_university}, function (data) {
                $('.item_home_page').html(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_department_id_box() {
    try {
        $('.res_item_university').unbind('click').click(function () {
            var box_university = $(this).children('span:first').html();
            $.post('../Admin/handler.php', {box_university: box_university}, function (data) {
                $('#txt_university_id').val(data);
                var uni = $('#txt_university_id').val();
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_details_link() {
    $('.link_view_details').unbind('click').click(function () {
        var year_by_department = $(this).attr('value');
        $.post('../Admin/handler.php', {year_by_department: year_by_department}, function (data) {
            $('.item_home_page').html(data);
            
        });
        return false;
    });
}
function get_deaprtments_by_university_combo() {
    try {
        $('.cbo_department').change(function () {
            var cbo_department = $('.cbo_department option:selected').text();
            $.post('../Admin/handler.php', {cbo_department: cbo_department}, function (data) {
                $('#txt_department_id').val(data);

            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_student_showed() {
    $('#link_select_student, .tests_table_performers').click(function () {
        $('#dialog_students').show(300);
        $('#dialog_child').fadeIn(300);
    });
}
function get_hide_selectable_students() {
    $('#dialog_students').click(function () {
        $('#dialog_students').hide(300);
        $('#dialog_child').fadeOut(300);
    });
}
function get_students_selected() {
    $('.selector_link').click(function () {
        var id = $(this).attr('value');
        $('#txt_student_id').val(id);
        $('#dialog_students').hide(300);
        $('#dialog_child').fadeOut(300);
    });
}
function get_students_by_row() {
    $('#seletable_student_table').find('tr').click(function () {
        var student_id = $(this).find('td').eq(0).html().trim();
        $('#txt_student_id').val(student_id);
        var school = $(this).find('td').eq(6).html().trim();
        $('#txt_school_name').val(school);
        $('#dialog_students').hide(300);
        $('#dialog_child').fadeOut(300);

    });
}
function get_clickable_row() {
    $('.tests_table_performers').find('tr').click(function () {
        var row = $(this).find('td:first').text();
        uni = $(this).find("td").eq(4).html();
        dep = $(this).find('td').eq(5).html();
        uni_name = $(this).find('td').eq(9).html();
        student_id = $(this).find('td').eq(3).html();
        student_name = $(this).find('td').eq(4).html();
        $('#txt_student_id').val(student_id);
        $('#student_name').val(student_name);
        $('#txt_school_name').val(uni_name);
    });
}
function get_suspend_click() {
    $('.suspend_link').click(function () {
        try {
            var row = $(this).closest('td').siblings('.t1').text();
            var suspend_req = row;
            var this_row = $(this);
            $.post('../Admin/handler.php', {suspend_req: suspend_req}, function (data) {

            }).complete(function () {
                $(this_row).closest('tr').hide(400);
            });
        } catch (err) {
            alert(err.message);
        }
    });
}
//cbo_dep_special
  